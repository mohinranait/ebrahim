"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Github,
  Linkedin,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Code,
  Database,
  Server,
  Smartphone,
  ExternalLink,
  Download,
  Moon,
  Sun,
  Menu,
  X,
  User,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useTheme } from "next-themes"
import Link from "next/link"
import { useApi, apiRequest } from "@/hooks/useApi"

const iconMap: { [key: string]: any } = {
  Code,
  Server,
  Database,
  Smartphone,
}

interface Project {
  _id: string
  title: string
  description: string
  image: string
  technologies: string[]
  liveUrl: string
  githubUrl: string
  featured: boolean
}

interface Skill {
  _id: string
  name: string
  level: number
  category: string
  icon: string
}

interface PersonalInfo {
  _id: string
  name: string
  title: string
  bio: string
  email: string
  phone: string
  location: string
  company: string
  joinDate: string
  avatar: string
  socialLinks: {
    github?: string
    linkedin?: string
    twitter?: string
    website?: string
  }
  resumeUrl?: string
}

// Add these interfaces after the existing ones
interface Experience {
  _id: string
  company: string
  position: string
  type: string
  startDate: string
  endDate?: string
  current: boolean
  description: string
  achievements: string[]
  technologies: string[]
  teamSize?: string
  location?: string
}

interface Technology {
  _id: string
  name: string
  category: string
  icon: string
  color: string
}

export default function Portfolio() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState("home")
  const [contactForm, setContactForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // API calls
  const { data: projects, loading: projectsLoading } = useApi<Project[]>("/api/projects")
  const { data: skills, loading: skillsLoading } = useApi<Skill[]>("/api/skills")
  const { data: personalInfo, loading: personalInfoLoading } = useApi<PersonalInfo>("/api/personal-info")

  // Add these API calls after the existing ones
  const { data: experiences, loading: experiencesLoading } = useApi<Experience[]>("/api/experiences")
  const { data: technologies, loading: technologiesLoading } = useApi<Technology[]>("/api/technologies")

  useEffect(() => {
    setMounted(true)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setActiveSection(sectionId)
      setIsMenuOpen(false)
    }
  }

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    const result = await apiRequest("/api/contact", {
      method: "POST",
      body: JSON.stringify(contactForm),
    })

    if (result.success) {
      alert("Message sent successfully!")
      setContactForm({
        firstName: "",
        lastName: "",
        email: "",
        subject: "",
        message: "",
      })
    } else {
      alert("Failed to send message. Please try again.")
    }

    setIsSubmitting(false)
  }

  if (!mounted) return null

  const featuredProjects = projects?.filter((p) => p.featured) || []
  const allProjects = projects || []

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900 transition-colors duration-300">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border-b border-white/20 dark:border-gray-700/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"
            >
              {personalInfo?.name || "Portfolio"}
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {["home", "about", "experience", "skills", "projects", "contact"].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`capitalize transition-colors duration-200 ${
                    activeSection === item
                      ? "text-blue-600 dark:text-blue-400"
                      : "text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                  }`}
                >
                  {item}
                </button>
              ))}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="ml-4"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Link href="/admin">
                <Button variant="outline" size="sm">
                  Admin
                </Button>
              </Link>
            </div>

            {/* Mobile Navigation */}
            <div className="md:hidden flex items-center space-x-2">
              <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-t border-white/20 dark:border-gray-700/20"
            >
              <div className="px-4 py-4 space-y-2">
                {["home", "about", "experience", "skills", "projects", "contact"].map((item) => (
                  <button
                    key={item}
                    onClick={() => scrollToSection(item)}
                    className="block w-full text-left px-4 py-2 capitalize text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-200"
                  >
                    {item}
                  </button>
                ))}
                <Link href="/admin" className="block">
                  <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                    Admin Panel
                  </Button>
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="text-5xl lg:text-7xl font-bold mb-6"
            >
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                {personalInfo?.title?.split(" ")[0] || "MERN"}
              </span>
              <br />
              <span className="text-gray-800 dark:text-white">
                {personalInfo?.title?.split(" ").slice(1).join(" ") || "Developer"}
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="text-xl text-gray-600 dark:text-gray-300 mb-8 leading-relaxed"
            >
              {personalInfo?.bio || "Loading..."}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3"
                onClick={() => scrollToSection("projects")}
              >
                View My Work
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="px-8 py-3 border-2 hover:bg-blue-50 dark:hover:bg-gray-800 bg-transparent"
                onClick={() =>
                  personalInfo?.resumeUrl ? window.open(personalInfo.resumeUrl) : scrollToSection("contact")
                }
              >
                <Download className="mr-2 h-4 w-4" />
                Download CV
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="flex justify-center lg:justify-start space-x-6 mt-8"
            >
              {[
                { icon: Github, href: personalInfo?.socialLinks?.github || "#" },
                { icon: Linkedin, href: personalInfo?.socialLinks?.linkedin || "#" },
                { icon: Mail, href: `mailto:${personalInfo?.email || "your.email@example.com"}` },
              ].map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-3 rounded-full bg-white/20 dark:bg-gray-800/20 backdrop-blur-sm border border-white/30 dark:border-gray-700/30 hover:bg-white/30 dark:hover:bg-gray-700/30 transition-all duration-300"
                >
                  <social.icon className="h-6 w-6 text-gray-700 dark:text-gray-300" />
                </motion.a>
              ))}
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="relative"
          >
            <div className="relative w-80 h-80 mx-auto">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-3xl opacity-30 animate-pulse"></div>
              <div className="relative w-full h-full bg-gradient-to-br from-white/20 to-white/5 dark:from-gray-800/20 dark:to-gray-900/5 backdrop-blur-xl rounded-full border border-white/30 dark:border-gray-700/30 flex items-center justify-center">
                <div className="text-8xl">{personalInfo?.avatar || "👨‍💻"}</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              About Me
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Passionate full-stack developer with expertise in modern web technologies
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">My Journey</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                    {personalInfo?.bio || "Loading..."}
                  </p>

                  <div className="grid grid-cols-2 gap-4 mt-8">
                    <div className="flex items-center space-x-3">
                      <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">Experience</p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Since{" "}
                          {personalInfo?.joinDate
                            ? new Date(personalInfo.joinDate).toLocaleDateString("en-US", {
                                month: "long",
                                year: "numeric",
                              })
                            : "March 2024"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <MapPin className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">Company</p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">{personalInfo?.company || "ts4u"}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30">
                <CardContent className="p-6">
                  <h4 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">What I Do</h4>
                  <ul className="space-y-3">
                    {[
                      "Full-stack web application development",
                      "RESTful API design and implementation",
                      "Database design and optimization",
                      "Responsive UI/UX development",
                      "Performance optimization",
                      "Code review and mentoring",
                    ].map((item, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full"></div>
                        <span className="text-gray-600 dark:text-gray-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Professional Experience
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              My journey in software development and the companies I've worked with
            </p>
          </motion.div>

          {experiencesLoading ? (
            <div className="text-center">Loading experiences...</div>
          ) : (
            <div className="space-y-8">
              {experiences?.map((experience, index) => (
                <motion.div
                  key={experience._id}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30 hover:bg-white/30 dark:hover:bg-gray-700/30 transition-all duration-300">
                    <CardContent className="p-8">
                      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-2xl font-bold text-gray-800 dark:text-white">{experience.position}</h3>
                            {experience.current && (
                              <Badge className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
                                Current
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center space-x-4 mb-4">
                            <h4 className="text-xl font-semibold text-blue-600 dark:text-blue-400">
                              {experience.company}
                            </h4>
                            <Badge variant="outline" className="capitalize">
                              {experience.type}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300 mb-4">
                            <div className="flex items-center space-x-1">
                              <Calendar className="h-4 w-4" />
                              <span>
                                {new Date(experience.startDate).toLocaleDateString("en-US", {
                                  month: "long",
                                  year: "numeric",
                                })}{" "}
                                -{" "}
                                {experience.current
                                  ? "Present"
                                  : new Date(experience.endDate!).toLocaleDateString("en-US", {
                                      month: "long",
                                      year: "numeric",
                                    })}
                              </span>
                            </div>
                            {experience.location && (
                              <div className="flex items-center space-x-1">
                                <MapPin className="h-4 w-4" />
                                <span>{experience.location}</span>
                              </div>
                            )}
                            {experience.teamSize && (
                              <div className="flex items-center space-x-1">
                                <User className="h-4 w-4" />
                                <span>{experience.teamSize}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">{experience.description}</p>

                      {experience.achievements && experience.achievements.length > 0 && (
                        <div className="mb-6">
                          <h5 className="font-semibold text-gray-800 dark:text-white mb-3">Key Achievements:</h5>
                          <ul className="space-y-2">
                            {experience.achievements.map((achievement, idx) => (
                              <li key={idx} className="flex items-start space-x-3">
                                <div className="w-2 h-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                                <span className="text-gray-600 dark:text-gray-300">{achievement}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {experience.technologies && experience.technologies.length > 0 && (
                        <div>
                          <h5 className="font-semibold text-gray-800 dark:text-white mb-3">Technologies Used:</h5>
                          <div className="flex flex-wrap gap-2">
                            {experience.technologies.map((tech) => (
                              <Badge
                                key={tech}
                                variant="secondary"
                                className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300"
                              >
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Timeline connector */}
                  {index < (experiences?.length || 0) - 1 && (
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-px h-8 bg-gradient-to-b from-blue-600 to-purple-600 mt-4"></div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Skills Section */}
      <section
        id="skills"
        className="py-20 px-4 bg-gradient-to-r from-blue-50/50 to-purple-50/50 dark:from-gray-800/50 dark:to-purple-900/50"
      >
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Skills & Expertise
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Technologies and tools I work with to bring ideas to life
            </p>
          </motion.div>

          {skillsLoading ? (
            <div className="text-center">Loading skills...</div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {skills?.map((skill, index) => {
                const IconComponent = iconMap[skill.icon] || Code
                return (
                  <motion.div
                    key={skill._id}
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.05 }}
                  >
                    <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30 hover:bg-white/30 dark:hover:bg-gray-700/30 transition-all duration-300">
                      <CardContent className="p-6 text-center">
                        <IconComponent className="h-12 w-12 mx-auto mb-4 text-blue-600 dark:text-blue-400" />
                        <h3 className="text-lg font-semibold mb-3 text-gray-800 dark:text-white">{skill.name}</h3>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-2">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${skill.level}%` }}
                            transition={{ duration: 1, delay: index * 0.1 }}
                            viewport={{ once: true }}
                            className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full"
                          ></motion.div>
                        </div>
                        <span className="text-sm text-gray-600 dark:text-gray-300">{skill.level}%</span>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Featured Projects
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              A showcase of my recent work and personal projects
            </p>
          </motion.div>

          {projectsLoading ? (
            <div className="text-center">Loading projects...</div>
          ) : (
            <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
              {allProjects.map((project, index) => (
                <motion.div
                  key={project._id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -10 }}
                  className={project.featured ? "lg:col-span-2 xl:col-span-1" : ""}
                >
                  <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30 hover:bg-white/30 dark:hover:bg-gray-700/30 transition-all duration-300 overflow-hidden group h-full">
                    <div className="relative overflow-hidden">
                      <img
                        src={project.image || "/placeholder.svg"}
                        alt={project.title}
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      {project.featured && (
                        <div className="absolute top-4 right-4">
                          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0">
                            ⭐ Featured
                          </Badge>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-6 flex flex-col h-full">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">
                          {project.title}
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3 leading-relaxed">
                          {project.description}
                        </p>

                        <div className="flex flex-wrap gap-2 mb-6">
                          {project.technologies.map((tech) => {
                            const techData = technologies?.find((t) => t.name === tech)
                            return (
                              <Badge
                                key={tech}
                                variant="secondary"
                                className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 hover:scale-105 transition-transform duration-200"
                                style={{
                                  backgroundColor: techData?.color ? `${techData.color}20` : undefined,
                                  borderColor: techData?.color || undefined,
                                }}
                              >
                                {tech}
                              </Badge>
                            )
                          })}
                        </div>
                      </div>

                      <div className="flex space-x-3 mt-auto">
                        <Button
                          size="sm"
                          className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transition-all duration-300 hover:shadow-lg"
                          asChild
                        >
                          <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="mr-2 h-4 w-4" />
                            Live Demo
                          </a>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300 hover:scale-105 bg-transparent"
                          asChild
                        >
                          <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                            <Github className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="py-20 px-4 bg-gradient-to-r from-blue-50/50 to-purple-50/50 dark:from-gray-800/50 dark:to-purple-900/50"
      >
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Let's discuss your next project or collaboration opportunity
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">Contact Information</h3>

                  <div className="space-y-6">
                    {[
                      {
                        icon: Mail,
                        label: "Email",
                        value: personalInfo?.email || "your.email@example.com",
                        href: `mailto:${personalInfo?.email || "your.email@example.com"}`,
                      },
                      {
                        icon: Phone,
                        label: "Phone",
                        value: personalInfo?.phone || "+1 (555) 123-4567",
                        href: `tel:${personalInfo?.phone || "+15551234567"}`,
                      },
                      {
                        icon: MapPin,
                        label: "Location",
                        value: personalInfo?.location || "Your City, Country",
                        href: "#",
                      },
                    ].map((contact, index) => (
                      <motion.a
                        key={index}
                        href={contact.href}
                        whileHover={{ scale: 1.02 }}
                        className="flex items-center space-x-4 p-4 rounded-lg bg-white/10 dark:bg-gray-700/10 hover:bg-white/20 dark:hover:bg-gray-600/20 transition-all duration-300"
                      >
                        <contact.icon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                        <div>
                          <p className="font-semibold text-gray-800 dark:text-white">{contact.label}</p>
                          <p className="text-gray-600 dark:text-gray-300">{contact.value}</p>
                        </div>
                      </motion.a>
                    ))}
                  </div>

                  <div className="mt-8 pt-8 border-t border-white/20 dark:border-gray-700/20">
                    <h4 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Follow Me</h4>
                    <div className="flex space-x-4">
                      {[
                        { icon: Github, href: personalInfo?.socialLinks?.github || "#" },
                        { icon: Linkedin, href: personalInfo?.socialLinks?.linkedin || "#" },
                        { icon: Mail, href: `mailto:${personalInfo?.email || "your.email@example.com"}` },
                      ].map((social, index) => (
                        <motion.a
                          key={index}
                          href={social.href}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.95 }}
                          className="p-3 rounded-full bg-white/20 dark:bg-gray-800/20 backdrop-blur-sm border border-white/30 dark:border-gray-700/30 hover:bg-white/30 dark:hover:bg-gray-700/30 transition-all duration-300"
                        >
                          <social.icon className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                        </motion.a>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white/20 dark:bg-gray-800/20 backdrop-blur-xl border border-white/30 dark:border-gray-700/30">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">Send Message</h3>

                  <form onSubmit={handleContactSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          First Name
                        </label>
                        <Input
                          placeholder="John"
                          value={contactForm.firstName}
                          onChange={(e) => setContactForm({ ...contactForm, firstName: e.target.value })}
                          className="bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-700/30"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Last Name
                        </label>
                        <Input
                          placeholder="Doe"
                          value={contactForm.lastName}
                          onChange={(e) => setContactForm({ ...contactForm, lastName: e.target.value })}
                          className="bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-700/30"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Email</label>
                      <Input
                        type="email"
                        placeholder="john@example.com"
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        className="bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-700/30"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Subject</label>
                      <Input
                        placeholder="Project Discussion"
                        value={contactForm.subject}
                        onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                        className="bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-700/30"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Message</label>
                      <Textarea
                        placeholder="Tell me about your project..."
                        rows={5}
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        className="bg-white/50 dark:bg-gray-800/50 border-white/30 dark:border-gray-700/30"
                        required
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                    >
                      {isSubmitting ? "Sending..." : "Send Message"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-white/20 dark:border-gray-700/20">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-600 dark:text-gray-300">
            © 2024 {personalInfo?.name || "Portfolio"}. Built with Next.js and Tailwind CSS.
          </p>
        </div>
      </footer>
    </div>
  )
}
